import User from '../models/User';

export const getDashboardData = async (req, res) => {
    const { userId } = req.user;

    try {
        const user = await User.findById(userId);
        res.json({ user });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
