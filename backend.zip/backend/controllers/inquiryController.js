import Inquiry from '../models/Inquiry';

// Create a new inquiry
export const createInquiry = async (req, res) => {
    const { title, description, assignedTo } = req.body;

    const newInquiry = new Inquiry({ title, description, assignedTo });

    try {
        await newInquiry.save();
        res.status(201).json(newInquiry);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get inquiry by ID
export const getInquiryById = async (req, res) => {
    const { id } = req.params;

    try {
        const inquiry = await Inquiry.findById(id);
        if (!inquiry) {
            return res.status(404).json({ message: 'Inquiry not found' });
        }
        res.json(inquiry);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get inquiries by assigned user
export const getInquiriesByUser = async (req, res) => {
    const { userId } = req.user;

    try {
        const inquiries = await Inquiry.find({ assignedTo: userId });
        res.json(inquiries);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
