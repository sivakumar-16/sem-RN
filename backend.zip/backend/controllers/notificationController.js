import Notification from '../models/Notification';

// Create a notification
export const createNotification = async (req, res) => {
    const { userId, message } = req.body;

    const newNotification = new Notification({ userId, message });

    try {
        await newNotification.save();
        res.status(201).json(newNotification);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Fetch notifications based on user type
export const getNotifications = async (req, res) => {
    const { userId } = req.user;

    try {
        const notifications = await Notification.find({ userId });
        res.json(notifications);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
