import Update from '../models/Update';

// Create a new update
export const createUpdate = async (req, res) => {
    const { content, department } = req.body;

    const newUpdate = new Update({ content, department });

    try {
        await newUpdate.save();
        res.status(201).json(newUpdate);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get updates by department
export const getUpdates = async (req, res) => {
    const { department } = req.query;

    try {
        const updates = department ? await Update.find({ department }) : await Update.find();
        res.json(updates);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
