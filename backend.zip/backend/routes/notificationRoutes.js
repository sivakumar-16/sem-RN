import express from 'express';
import { authenticateJWT } from '../middleware/authMiddleware.js';
import { createNotification, getNotifications } from '../controllers/notificationController.js';

const router = express.Router();

router.post('/', authenticateJWT, createNotification);
router.get('/', authenticateJWT, getNotifications);

export default router;
