import express from 'express';
import { authenticateJWT } from '../middleware/authMiddleware.js';
import { createUpdate, getUpdates } from '../controllers/updateController.js';

const router = express.Router();

router.post('/', authenticateJWT, createUpdate);
router.get('/', authenticateJWT, getUpdates);

export default router;
