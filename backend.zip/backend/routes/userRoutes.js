import express from 'express';
import { authenticateJWT } from '../middleware/authenticateJwt.js';
import { updateUser, getUser } from '../controllers/userController.js';

const router = express.Router();

router.get('/:userId', authenticateJWT, getUser);
router.put('/:userId', authenticateJWT, updateUser);

export default router;
