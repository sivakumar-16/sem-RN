import express from 'express';
import { authenticateJWT } from '../middleware/authMiddleware.js';
import { getDashboardData } from '../controllers/dashBoardController.js';

const router = express.Router();

router.get('/', authenticateJWT, getDashboardData);

export default router;
