import express from 'express';
import { authenticateJWT } from '../middleware/authMiddleware.js';
import { createInquiry, getInquiryById, getInquiriesByUser } from '../controllers/inquiryController.js';

const router = express.Router();

router.post('/', authenticateJWT, createInquiry);
router.get('/:id', authenticateJWT, getInquiryById);
router.get('/', authenticateJWT, getInquiriesByUser);

export default router;
