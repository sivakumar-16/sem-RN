import express from 'express';
import connectDB from './config/db.js'
import dotenv from 'dotenv';
import authRoutes from './routes/routes.js';
import userRoutes from './routes/userRoutes.js';
import updateRoutes from './routes/updateRoutes.js';
import inquiryRoutes from './routes/inquiryRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

// MongoDB connection
connectDB()
// Routes
app.use('/auth', authRoutes);
app.use('/users', userRoutes);
app.use('/updates', updateRoutes);
app.use('/inquiries', inquiryRoutes);
app.use('/notifications', notificationRoutes);
app.use('/dashboard', dashboardRoutes);

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
